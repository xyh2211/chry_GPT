import os
import json

import torch
from PIL import Image
from torchvision import transforms
import matplotlib.pyplot as plt

from model import efficientnet_b0 as create_model

def find_infloder(floder_path,image_extensions=('jpeg','jpg','png','gif')):
    img_files = []
    for root, dirs, files in os.walk(floder_path):
        for file in files:
            files_extension = file.split('.')[-1].lower()
            if files_extension in image_extensions:
                imgpth = os.path.join(root,file)
                img_files.append(imgpth)
    return img_files

def main():
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    img_size = {"B0": 224,
                "B1": 240,
                "B2": 260,
                "B3": 300,
                "B4": 380,
                "B5": 456,
                "B6": 528,
                "B7": 600}
    num_model = "B0"

    data_transform = transforms.Compose(
        [transforms.Resize(img_size[num_model]),
         transforms.CenterCrop(img_size[num_model]),
         transforms.ToTensor(),
         transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
    # create model
    model = create_model(num_classes=5).to(device)
    # load model weights
    model_weight_path = './weights/model-797.pth'
    model.load_state_dict(torch.load(model_weight_path, map_location=device))
    model.eval()

    # load image
    floder_path = "/home/ti3080/dataset/2023znzz/Train/A-TEST"
    img_files = find_infloder(floder_path)
    totol_sample = int(len(img_files))
    print(totol_sample)
    TP0 = 0
    TP1 = 0
    TP2 = 0
    TP3 = 0
    TP4 = 0
    FP0 = 0
    FP1 = 0
    FP2 = 0
    FP3 = 0
    FP4 = 0
    FN0 = 0
    FN1 = 0
    FN2 = 0
    FN3 = 0
    FN4 = 0
    correct = 0
    for img_path in img_files:
        img_labels = img_path.split('/')[-2]
        assert os.path.exists(img_path), "file: '{}' dose not exist.".format(img_path)
        img = Image.open(img_path)
        plt.imshow(img)
        # [N, C, H, W]
        img = data_transform(img)
        # expand batch dimension
        img = torch.unsqueeze(img, dim=0)
        with torch.no_grad():
            # predict class
            output = torch.squeeze(model(img.to(device))).cpu()
            predict = torch.softmax(output, dim=0)
            predict_cla = torch.argmax(predict).numpy()
        if predict_cla == 0:
            if int(img_labels) == 0:
                TP0 += 1
            else:
                FP0 += 1
        elif int(img_labels) == 0:
            FN0 += 1

        if predict_cla == 1:
            if int(img_labels) == 1:
                TP1 += 1
            else:
                FP1 += 1
        elif int(img_labels) == 1:
            FN1 += 1
        if predict_cla == 2:
            if int(img_labels) == 2:
                TP2 += 1
            else:
                FP2 += 1
        elif int(img_labels) == 2:
            FN2 += 1
        if predict_cla == 3:
            if int(img_labels) == 3:
                TP3 += 1
            else:
                FP3 += 1
        elif int(img_labels) == 3:
            FN3 += 1
        if predict_cla == 4:
            if int(img_labels) == 4:
                TP4 += 1
            else:
                FP4 += 1
        elif int(img_labels) == 4:
            FN4 += 1

    precission0 = TP0 / (TP0 + FP0)
    precission1 = TP1 / (TP1 + FP1)
    precission2 = TP2 / (TP2 + FP2)
    precission3 = TP3 / (TP3 + FP3)
    precission4 = TP4 / (TP4 + FP4)
    recall0 = TP0 / (TP0 + FN0)
    recall1 = TP1 / (TP1 + FN1)
    recall2 = TP2 / (TP2 + FN2)
    recall3 = TP3 / (TP3 + FN3)
    recall4 = TP4 / (TP4 + FN4)
    F1score0 = (2 * precission0 * recall0) / (precission0 + recall0)
    F1score1 = (2 * precission1 * recall1) / (precission1 + recall1)
    F1score2 = (2 * precission2 * recall2) / (precission2 + recall2)
    F1score3 = (2 * precission3 * recall3) / (precission3 + recall3)
    F1score4 = (2 * precission4 * recall4) / (precission4 + recall4)
    print(f'0精确率{precission0};1精确率{precission1};2精确率{precission2};3精确率{precission3};4精确率{precission4};')
    avg_acc = correct / totol_sample
    print(f'准确率 {avg_acc} ')





if __name__ == '__main__':
    main()
