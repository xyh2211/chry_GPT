#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
    Created time: 2023/9/12.
    @author: Yu Gong
    @Copyright © 2023 
    @Email: 1757758135@qq.com
    @Update time: 2023/9/12
    All Rights Reserved.
"""
import numpy as np
from tftb.processing import WignerVilleDistribution

def data2wvd(save_root ,sig):
    '''
    numlen:一条数据的长度
    save_path:保存的文件名
    length:一条数据总长度
    width：数据的总长度
    '''
    save_path = save_root
    print(save_path)
    wvd = WignerVilleDistribution(sig)
    wvd.run()
    wvd.plot(kind="contour", scale="log", location=save_path)
    return 0


import csv

import os
import numpy as np
import pandas as pd



for i in range(5):

    file_root = './DATASET/CSV/outputB'+str(i)+'.csv'
    # file_path = os.listdir(file_root)
    # for file_name in file_path:
    #     file_name = os.path.join(file_root,file_name)
    #     # 检查文件是否是CSV文件
    if file_root.endswith('.csv'):
        # 读取CSV文件
        df = pd.read_csv(file_root)

        # 提取第一列数据
        column_name = df.columns[0]
        data = df[column_name].values
        data = np.array(data)
        for j in range(0, len(data), 4096):
            data_split = data[j:j + 4096]
            # 构造保存的文件名，以原文件名命名，但将扩展名改为.npy
            save_name ='B'+str(i)+'-'+str(j)+'-50khz.jpg'
            print(save_name)
            #save_name = os.path.splitext(file_path[0])+'/' +str(j)+'.jpg'
            save_path = os.path.join('./DATASET/PICTURE_ORIGIN/B'+str(i), save_name)

            # 保存数据为.npy文件
            data2wvd(save_path, data_split)

# 完成任务
print("数据已保存为.npy文件并以原文件命名，保存在原文件路径下。")

# 打开CSV文件
# with open('./Train/A/4/A_4.csv', 'r') as csvfile:
#     # 使用csv.reader来读取文件
#     csvreader = csv.reader(csvfile)
#
#     # 初始化一个空列表来存储第二列的数据
#     second_column_data = []
#
#     # 逐行读取CSV文件
#     for row in csvreader:
#         # 确保行至少有两列（假设第二列存在）
#         if len(row) >= 2:
#             # 将第二列的数据添加到列表中
#             second_column_data.append(float(row[1]))

#second_column_data = np.array(second_column_data)
# 现在，second_column_data变量包含了CSV文件中第二列的所有数据
#data2wvd('.',second_column_data[:360])
