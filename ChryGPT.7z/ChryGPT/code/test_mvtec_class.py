import os
from model.openllama import OpenLLAMAPEFTModel
import torch
from torchvision import transforms
from sklearn.metrics import roc_auc_score
from PIL import Image
import numpy as np
import argparse

parser = argparse.ArgumentParser("AnomalyGPT", add_help=True)
# paths
parser.add_argument("--few_shot", type=bool, default=True)
parser.add_argument("--k_shot", type=int, default=1)
parser.add_argument("--round", type=int, default=3)


command_args = parser.parse_args()


CLASS_NAMES = ['fissure', 'defect', 'fracture', 'corrosion', 'rust']
TEXTURES = ['fissure', 'defect', 'fracture', 'corrosion', 'rust']
input = "Which category does this picture belong to?"

root_dir = '../data/mvtec'




FEW_SHOT = command_args.few_shot 

# init the model
args = {
    'model': 'openllama_peft',
    'imagebind_ckpt_path': '../pretrained_ckpt/imagebind_ckpt/imagebind_huge.pth',
    'vicuna_ckpt_path': '../pretrained_ckpt/vicuna_ckpt/7b_v0',
    'anomalygpt_ckpt_path': './ckpt/train_mvtec/200/pytorch_model.pt',
    'delta_ckpt_path': '../pretrained_ckpt/pandagpt_ckpt/7b/pytorch_model.pt',
    'stage': 2,
    'max_tgt_len': 128,
    'lora_r': 32,
    'lora_alpha': 32,
    'lora_dropout': 0.1,
}

model = OpenLLAMAPEFTModel(**args)
delta_ckpt = torch.load(args['delta_ckpt_path'], map_location=torch.device('cpu'))
model.load_state_dict(delta_ckpt, strict=False)
delta_ckpt = torch.load(args['anomalygpt_ckpt_path'], map_location=torch.device('cpu'))
model.load_state_dict(delta_ckpt, strict=False)
model = model.eval().half().cuda()

print(f'[!] init the 7b model over ...')

"""Override Chatbot.postprocess"""
p_auc_list = []
i_auc_list = []

def predict(
    input, 
    image_path, 
    normal_img_path, 
    max_length, 
    top_p, 
    temperature,
    history,
    modality_cache,  
):
    prompt_text = ''
    for idx, (q, a) in enumerate(history):
        if idx == 0:
            prompt_text += f'{q}\n### Assistant: {a}\n###'
        else:
            prompt_text += f' Human: {q}\n### Assistant: {a}\n###'
    if len(history) == 0:
        prompt_text += f'{input}'
    else:
        prompt_text += f' Human: {input}'

    response, pixel_output = model.generate({
        'prompt': prompt_text,
        'image_paths': [image_path] if image_path else [],
        'audio_paths': [],
        'video_paths': [],
        'thermal_paths': [],
        'normal_img_paths': normal_img_path if normal_img_path else [],
        'top_p': top_p,
        'temperature': temperature,
        'max_tgt_len': max_length,
        'modality_embeds': modality_cache
    })

    return response, pixel_output



mask_transform = transforms.Compose([
                                transforms.Resize((224, 224)),
                                transforms.ToTensor()
                            ])




precision = []

# 两个文件
# 一
# 1. train good
# 2. test good
# 1，2用于测试，输出准确率

# 二
# forward 直接前传播得到计算类别

for c_name in CLASS_NAMES:
    right = 0
    wrong = 0
    p_pred = []
    p_label = []
    i_pred = []
    i_label = []
    # /home/user/git_code/cometition/AnomalyGPT/data/mvtec/Working_0/test/good/A0163840.jpg
    for root, dirs, files in os.walk(root_dir + "/" +c_name):
        for file in files:
            # file_path图片路径名
            file_path = os.path.join(root, file)
            if ("test" in file_path  or "train" in file_path) and 'good' in file_path and ('png' in file or 'jpg' in file) and c_name in file_path:
                # input = input_template.format(c_name)
                resp, anomaly_map = predict(input, file_path, [], 512, 0.1, 1.0, [], [])
                print(resp)
                if (c_name in resp) :
                    right += 1
                else:
                    wrong += 1
            else:
                pass
    precision.append(100 * right / (right + wrong))
    print(c_name, 'right:',right,'wrong:',wrong)

print("precision:",torch.tensor(precision).mean())