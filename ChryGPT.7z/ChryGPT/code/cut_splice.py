import csv
import random



# 读取CSV文件
with open('/home/ti3080/dataset/B/B/B4/B_4.csv', 'r') as csvfile0:
    reader = csv.reader(csvfile0)
    data0 = [row[1] for row in reader]
with open('/home/ti3080/dataset/B/B/B0/B_0.csv', 'r') as csvfile1:
    reader = csv.reader(csvfile1)
    data1 = [row[1] for row in reader]


# 创建一个txt文件来记录随机切割的位置
txt_file_0 = open('./DATASET/TXT/random_cut_positions_puctureB4.txt', 'w')
txt_file_1 = open('./DATASET/TXT/random_cut_positionsB4.txt', 'w')
# 创建一个空列表来保存拼接后的数据
result_data = []



# 以间隔4096切割数据
interval0 = 3072
interval1 = 1024
for i in range(0, len(data0), interval0):

    j = int(i/3)
    k = 4*j
    chunk0 = data0[i:i + interval0]
    chunk1 = data1[j:j + interval1]
    # 随机切割并记录位置
    random_cut_position = random.randint(0, len(chunk0))
    txt_file_0.write(f"{random_cut_position}\n")
    txt_file_1.write(f"{k+random_cut_position}\n")
    # 切割并拼接数据
    chunk_start = chunk0[:random_cut_position]
    chunk_end = chunk0[random_cut_position:]
    result_data.extend(chunk_start)
    result_data.extend(chunk1)
    result_data.extend(chunk_end)
    # print("i=",i)
    # print("j=",j)



# 关闭txt文件
txt_file_0.close()
txt_file_1.close()

# 将拼接后的数据保存到新的CSV文件中

with open('./DATASET/CSV/outputB4.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows([[row] for row in result_data])