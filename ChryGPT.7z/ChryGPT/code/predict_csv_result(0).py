import numpy as np
from tftb.processing import WignerVilleDistribution
import csv

import os
import numpy as np
import pandas as pd
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
import json

import torch
from PIL import Image
from torchvision import transforms
import matplotlib.pyplot as plt

import os
from model.openllama import OpenLLAMAPEFTModel
import torch
from torchvision import transforms
import numpy as np
import argparse

parser = argparse.ArgumentParser("AnomalyGPT", add_help=True)
# paths
parser.add_argument("--few_shot", type=bool, default=True)
parser.add_argument("--k_shot", type=int, default=1)
parser.add_argument("--round", type=int, default=3)


command_args = parser.parse_args()


CLASS_NAMES = ['fissure', 'defect', 'fracture', 'corrosion', 'rust']
TEXTURES = ['fissure', 'defect', 'fracture', 'corrosion', 'rust']
input = "Which category does this picture belong to?"


FEW_SHOT = command_args.few_shot

# init the model
args = {
    'model': 'openllama_peft',
    'imagebind_ckpt_path': '../pretrained_ckpt/imagebind_ckpt/imagebind_huge.pth',
    'vicuna_ckpt_path': '../pretrained_ckpt/vicuna_ckpt/7b_v0',
    'anomalygpt_ckpt_path': './ckpt/train_mvtec/200/pytorch_model.pt',
    'delta_ckpt_path': '../pretrained_ckpt/pandagpt_ckpt/7b/pytorch_model.pt',
    'stage': 2,
    'max_tgt_len': 128,
    'lora_r': 32,
    'lora_alpha': 32,
    'lora_dropout': 0.1,
}

model = OpenLLAMAPEFTModel(**args)
delta_ckpt = torch.load(args['delta_ckpt_path'], map_location=torch.device('cpu'))
model.load_state_dict(delta_ckpt, strict=False)
delta_ckpt = torch.load(args['anomalygpt_ckpt_path'], map_location=torch.device('cpu'))
model.load_state_dict(delta_ckpt, strict=False)
model = model.eval().half().cuda()


print(f'[!] init the 7b model over ...')

"""Override Chatbot.postprocess"""
p_auc_list = []
i_auc_list = []

def predict(
    input,
    image_path,
    normal_img_path,
    max_length,
    top_p,
    temperature,
    history,
    modality_cache,
):
    prompt_text = ''
    for idx, (q, a) in enumerate(history):
        if idx == 0:
            prompt_text += f'{q}\n### Assistant: {a}\n###'
        else:
            prompt_text += f' Human: {q}\n### Assistant: {a}\n###'
    if len(history) == 0:
        prompt_text += f'{input}'
    else:
        prompt_text += f' Human: {input}'

    response, pixel_output = model.generate({
        'prompt': prompt_text,
        'image_paths': [image_path] if image_path else [],
        'audio_paths': [],
        'video_paths': [],
        'thermal_paths': [],
        'normal_img_paths': normal_img_path if normal_img_path else [],
        'top_p': top_p,
        'temperature': temperature,
        'max_tgt_len': max_length,
        'modality_embeds': modality_cache
    })

    return response, pixel_output



mask_transform = transforms.Compose([
                                transforms.Resize((224, 224)),
                                transforms.ToTensor()
                            ])

def data2wvd(save_root ,sig):
    '''
    numlen:一条数据的长度
    save_path:保存的文件名
    length:一条数据总长度
    width：数据的总长度
    '''
    save_path = save_root
    # print(save_path)
    wvd = WignerVilleDistribution(sig)
    wvd.run()
    wvd.plot(kind="contour", scale="log", location=save_path)
    return 0

def find_infloder(floder_path,image_extensions=('jpeg','jpg','png','gif')):
    img_files = []
    for root, dirs, files in os.walk(floder_path):
        for file in files:
            files_extension = file.split('.')[-1].lower()
            if files_extension in image_extensions:
                imgpth = os.path.join(root,file)
                img_files.append(imgpth)
    return img_files




filehead = ('样本', '类别')
csv_file = 'test2.csv'

# 定义主文件夹路径
main_folder_path = '/home/user/DISK/datasets/data/TEST/Test1'
# 遍历主文件夹下的所有子文件夹

with open(csv_file,mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(filehead)
    # 遍历子文件夹下的所有CSV文件
    for file_name1 in os.listdir(main_folder_path):
        file_path1 = os.path.join(main_folder_path, file_name1)
        # 检查文件是否是CSV文件
        if file_name1.endswith('.csv'):
            # 读取CSV文件
            df = pd.read_csv(file_path1)

            # 提取第二列数据
            column_name = df.columns[1]
            data = df[column_name].values
            data = np.array(data)
            flodernew = file_path1.split('.csv')[0]
#
            data_split = data[:4096]
            # 构造保存的文件名，以原文件名命名，但将扩展名改为.npy
            save_path = flodernew +'.jpg'
            data2wvd(save_path, data_split)
            # load image
            class_count = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0}
            assert os.path.exists(save_path), "file: '{}' dose not exist.".format(save_path)

            with torch.no_grad():
                # predict class
                resp, anomaly_map = predict(input, save_path, [], 512, 0.1, 1.0, [], [])
                i = 0
                for cls in CLASS_NAMES:
                    if cls in resp:
                        predict_cla = i
                        class_count[int(predict_cla)] += 1
                        break
                    else:
                        i += 1
            maj_class = int(max(class_count, key=class_count.get))
            filenum = file_name1.split('.csv')[0]
            writer.writerow((filenum,maj_class))
            print(f'file {filenum}  maj_class is {maj_class}')

